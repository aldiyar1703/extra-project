// routes/achievements.js
const express = require('express');
const router = express.Router();
const Achievement = require('../models/Achievement');

// Получить все достижения
router.get('/', async (req, res) => {
    try {
        const achievements = await Achievement.find();
        res.json(achievements);
    } catch (err) {
        res.status(500).json({ message: 'Error fetching achievements' });
    }
});

// Создать новое достижение
router.post('/', async (req, res) => {
    try {
        const newAchievement = new Achievement(req.body);
        await newAchievement.save();
        res.json(newAchievement);
    } catch (err) {
        res.status(400).json({ message: 'Error creating achievement' });
    }
});

// Обновить достижение
router.put('/:id', async (req, res) => {
    try {
        const updatedAchievement = await Achievement.findByIdAndUpdate(req.params.id, req.body, { new: true });
        res.json(updatedAchievement);
    } catch (err) {
        res.status(400).json({ message: 'Error updating achievement' });
    }
});

// Удалить достижение
router.delete('/:id', async (req, res) => {
    try {
        await Achievement.findByIdAndDelete(req.params.id);
        res.json({ message: 'Achievement deleted' });
    } catch (err) {
        res.status(500).json({ message: 'Error deleting achievement' });
    }
});

module.exports = router;

// routes/auth.js
const express = require('express');
const router = express.Router();

// Пример простого маршрута для аутентификации
router.post('/login', (req, res) => {
    res.send('Login successful');
});

router.post('/register', (req, res) => {
    res.send('Registration successful');
});

module.exports = router;

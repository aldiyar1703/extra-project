const express = require('express');
const mongoose = require('mongoose');
const session = require('express-session');
const path = require('path');

const app = express();

// Подключение к MongoDB
mongoose.connect('mongodb+srv://aldiyardanilov:AAldiyar1717@cluster0.9spfn.mongodb.net/student-achievements?retryWrites=true&w=majority', {
    useNewUrlParser: true,
    useUnifiedTopology: true,
}).then(() => console.log('MongoDB connected'))
  .catch(err => console.log(err));

// Middleware
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public'))); // Статическая папка для HTML

// Маршрут для корневого пути, чтобы вернуть HTML-файл
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// Дополнительные маршруты API
// Например:
// const studentsRouter = require('./routes/students');
// app.use('/api/students', studentsRouter);

const PORT = 3500;
app.listen(PORT, () => {
    console.log(`Server is running on http://localhost:${PORT}`);
});

document.getElementById('achievement-form').addEventListener('submit', function(event) {
    event.preventDefault();
    const studentName = document.getElementById('studentName').value;
    const achievement = document.getElementById('achievement').value;

    // Добавление новой карточки для достижения
    const studentList = document.getElementById('student-list');
    const card = document.createElement('div');
    card.className = 'card col-md-4';
    card.innerHTML = `
        <div class="card-body">
            <h5 class="card-title">${studentName}</h5>
            <p class="card-text">${achievement}</p>
        </div>
    `;
    studentList.appendChild(card);

    // Очистка формы
    document.getElementById('achievement-form').reset();
});
